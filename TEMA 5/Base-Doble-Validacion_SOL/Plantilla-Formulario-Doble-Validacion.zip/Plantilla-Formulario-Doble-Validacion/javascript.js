let formulario=document.getElementById("miFormulario")

document.getElementById("idEnviar").addEventListener('click', validar);

function validar(evento){
    //Limpieza de INPUT
    for (let i=0; i<formulario.elements.length; i++){
        
        formulario.elements[i].classList.remove("errorInput")    
        formulario.elements[i].setCustomValidity("")
    }

    //Limpieza de SPAM
    document.querySelectorAll(".errorSpan").forEach(elemento=> elemento.innerHTML="")
    
    this.disabled=true    

    if(validarAPIHTML() && validarJS() && confirm("¿Deseas enviar el formulario?")){           
        return true;
    } else{

        evento.preventDefault();
        this.disabled=false
        return false
    }    
    

}


function validarAPIHTML(){
    return validarEdadAPI()
}

function validarJS(){
    return validarJSInteres() //&& validarCorreo() && validarFechaNacimiento()
}

function validarJSInteres(){

    let interes = new Set(["deportes","musica","viajes","y-mas"])
    let valorInteres = formulario.querySelectorAll("input[type='checkbox']")
    let span=document.getElementById('idInteresesError')  
    
    let error=""
    let seleccionado=false
    
    valorInteres.forEach(check =>{

        if(check.checked===true){
            seleccionado=true
            if(interes.has(check.value)===false){
                error+=`El valor: ${check.value} , no existe ; `
            }
        }
    })

    if(error!==""){

        span.innerHTML=error
        return false
    }
    if(seleccionado===false){
        span.innerHTML="Debe seleccionar un interés....."
        return false
    }

    return true

}

function validarEdadAPI(){

    let inputEdad= formulario["idEdad"]
    let span=document.getElementById("idEdadError")

    if(inputEdad.validity.valueMissing){

        let mensajeError= `Campo obligatorio`
        inputEdad.focus()
        inputEdad.setCustomValidity(mensajeError)
        span.innerHTML=inputEdad.validationMessage
        
        return false

    }  else if(inputEdad.validity.rangeUnderflow){

        let mensajeError= `Valor debe ser superior a 18`
        inputEdad.focus()
        inputEdad.setCustomValidity(mensajeError)
        span.innerHTML=inputEdad.validationMessage
        
        return false
    } else if(inputEdad.validity.rangeOverflow){

        let mensajeError= `Valor debe ser inferior a 99`
        inputEdad.focus()
        inputEdad.setCustomValidity(mensajeError)
        span.innerHTML=inputEdad.validationMessage
        
        return false
    }
        
    return true
}
