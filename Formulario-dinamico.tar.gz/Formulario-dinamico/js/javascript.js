// Aquí tu código JAVASCRIPT

const datosMultimediaArray = [
    {
      "Peliculas": [
        "Titanic",
        "Forrest Gump",
        "Avatar",
        "The Shawshank Redemption",
        "The Godfather",
        "Inception",
        "Pulp Fiction",
        "The Dark Knight",
        "Schindler's List",
        "The Matrix"
      ]
    },
    {
      "Series":[
        "Juego de Tronos",
        "Breaking Bad",
        "Stranger Things",
        "Friends",
        "The Crown",
        "Los Serrano"
      ]
    }
  ];
  
// datosMultimediaArray.forEach(ObJson => {
//   for(clave in ObJson){
//     //por cada clave de cada json creamos un input y datalist:
//     let input= document.createElement('input');
//     input.type="text";
//     input.name=clave + "-preferida";
//     input.id=clave + "-preferida";

//     let padre = document.getElementById("pelicula");

//     padre.appendChild(input);

//   }
// })


  //SEXO
  const generosSet = new Set(["Masculino", "Femenino", "Otro"]);

  let salto = document.createElement('br');
  let contenedorGen = document.getElementById("idSexo");
  contenedorGen.appendChild(salto);
    generosSet.forEach(genero => {
      let radios = document.createElement('input');
      radios.type='radio';
      radios.name='sexo';
      radios.value=genero;
      radios.id=genero;

      let labelRadio = document.createElement('label');
      labelRadio.htmlFor=genero;
      let descrip = document.createTextNode(genero);
      labelRadio.appendChild(descrip);

      contenedorGen.appendChild(radios); 
      contenedorGen.appendChild(labelRadio);
      //aplico salto de linea después del ultimo elemento:
    }); 

    contenedorGen.appendChild(document.createElement('br'));
     
//AFICIONES
  const aficionesMap = new Map([
    ["deportes", "Practicar deportes"],
    ["musica", "Escuchar música"],
    ["lectura", "Leer libros"],
    ["viajes", "Viajar"],
    ["otra", "Otra afición"]
]);

  //CREO SELECT DE AFICION:
  let select = document.createElement('select');
  select.id='aficion';
  select.name='aficion';
//foreach para recorrer aficionesmap:
aficionesMap.forEach((val, key) =>{
  //CREAR OPCIONES POR CADA Aficion:
  let option = document.createElement('option');
  option.value = key;
  let optionTexto = document.createTextNode(val);
  option.appendChild(optionTexto);

  let contenSelect =document.getElementById("idAficion");
  contenSelect.appendChild(select);
  select.appendChild(option);

});
contenedorGen.appendChild(document.createElement('br'))

  console.log("Los datos multimedia son :")
  console.log(datosMultimediaArray)
  
  console.log("Los valores de género son:")
  console.log(generosSet)

  console.log("La información de aficiones es:")
  console.log(aficionesMap)